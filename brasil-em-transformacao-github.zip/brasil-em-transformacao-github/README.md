# 🇧🇷 Brasil em Transformação
## Análise demográfica com foco no envelhecimento populacional — Censo 2022

Projeto acadêmico de Ciência de Dados que analisa a estrutura etária da população brasileira e o envelhecimento demográfico, com recortes por sexo e território, utilizando dados públicos do IBGE.

**Escopo:** exclusivamente Censo Demográfico 2022. O projeto não realiza comparação com 2010.

## Objetivos

- Investigar a composição etária da população brasileira.
- Analisar a participação da população com 60 anos ou mais.
- Comparar a estrutura demográfica entre Grandes Regiões e Unidades da Federação.
- Explorar diferenças na distribuição etária por sexo.
- Disponibilizar um dashboard interativo para exploração dos resultados.

## Fonte dos dados

- **Instituição:** Instituto Brasileiro de Geografia e Estatística (IBGE).
- **Sistema:** SIDRA — Sistema IBGE de Recuperação Automática.
- **Tabela:** 9514 — População residente, por sexo, idade e forma de declaração da idade.
- **Variável:** 93 — População residente (Pessoas).
- **Ano:** 2022.
- **Tabela oficial:** https://sidra.ibge.gov.br/tabela/9514
- **API:** https://apisidra.ibge.gov.br/

As consultas à API para Brasil, Grandes Regiões e Unidades da Federação estão registradas em `metadata/fontes_metodologia.json`.

## Metodologia

O notebook executa o fluxo completo:

1. Coleta dos dados diretamente da API SIDRA.
2. Armazenamento das respostas brutas.
3. Normalização dos registros de sexo, idade, território e população.
4. Deduplicação das idades simples.
5. Construção de faixas etárias mutuamente exclusivas a partir das idades simples, evitando dupla contagem de categorias agregadas.
6. Validação dos totais e da consistência entre as bases.
7. Análise exploratória e geração de relatórios.
8. Construção do dashboard interativo.

### Faixas etárias utilizadas

- 0 a 14 anos
- 15 a 59 anos
- 60 a 64 anos
- 65 a 79 anos
- 80 anos ou mais

## Resultados nacionais destacados

Valores calculados a partir dos dados tratados do Censo 2022:

| Indicador | Resultado |
|---|---:|
| População total | 203.080.756 |
| População de 0 a 14 anos | 40.129.261 |
| População de 15 a 59 anos | 130.838.005 |
| População de 60 anos ou mais | 32.113.490 |
| População de 80 anos ou mais | 4.586.954 |
| Participação da população 60+ | 15,81% |
| Participação da população 80+ | 2,26% |
| Índice de envelhecimento | 80,03 pessoas 60+ para cada 100 pessoas de 0 a 14 anos |
| Idade mediana estimada | 35 anos |

A validação do total nacional é realizada no próprio notebook, comparando o total calculado com a referência de 203.080.756 habitantes.

## Dashboard

O dashboard interativo apresenta:

- Indicadores principais: população, população 60+, índice de envelhecimento e idade mediana.
- Distribuição da população por grupos etários.
- Distribuição por idade simples.
- Pirâmide etária por sexo.
- População com 60 anos ou mais por território.

Os filtros permitem explorar ano, nível territorial, localidade e sexo. O projeto contempla somente o ano de 2022.

Capturas de tela do dashboard estão disponíveis em `images/`.

## Estrutura do repositório

```text
brasil-em-transformacao/
├── notebooks/
│   └── Brasil_em_Transformacao.ipynb
├── data/
│   ├── raw/
│   │   ├── sidra_2022_n1.csv
│   │   ├── sidra_2022_n2.csv
│   │   └── sidra_2022_n3.csv
│   └── processed/
│       ├── demografia_idade_simples.csv
│       └── demografia_tratada.csv
├── relatorios/
│   ├── envelhecimento_regioes.csv
│   ├── estrutura_etaria_brasil.csv
│   ├── estrutura_por_sexo.csv
│   ├── indicadores_nacionais.csv
│   └── ranking_estados.csv
├── metadata/
│   └── fontes_metodologia.json
├── images/
│   └── capturas do dashboard
├── README.md
├── requirements.txt
└── .gitignore
```

As respostas brutas da API SIDRA e o relatório de validação desta execução também estão incluídos no repositório.

## Como executar

O projeto foi desenvolvido para **Google Colab**.

1. Abra `notebooks/Brasil_em_Transformacao.ipynb` no Google Colab.
2. Selecione **Ambiente de execução → Executar tudo**.
3. Aguarde a coleta dos dados na API SIDRA.
4. Confira os resultados da célula de validação. Investigue eventuais avisos antes de utilizar os indicadores.
5. Execute as células de análise exploratória e dashboard.
6. Interaja com os filtros do dashboard.

Não é necessário instalar Python localmente para executar no Colab.

## Tecnologias

- Python
- Google Colab
- Pandas
- NumPy
- Requests
- Matplotlib
- ipywidgets
- API SIDRA/IBGE

## Armazenamento e reprodutibilidade

Durante a execução no Google Colab, os arquivos são gravados em `/content/brasil_em_transformacao/`. Esse diretório pertence ao ambiente temporário do Colab e pode ser apagado quando a sessão é encerrada ou reiniciada.

As bases tratadas e os relatórios principais gerados nesta execução estão versionados neste repositório. As respostas brutas da API podem ser regeneradas executando a primeira etapa do notebook.

## Limitações

- A análise retrata a população recenseada em 2022, não uma estimativa em tempo real.
- Não há comparação com o Censo 2010.
- A execução da etapa de coleta depende da disponibilidade da API SIDRA e de conexão com a internet.
- A idade 100 representa a categoria de 100 anos ou mais na base de idade simples.

## Referências

- IBGE — SIDRA, Tabela 9514: https://sidra.ibge.gov.br/tabela/9514
- IBGE — documentação da API de agregados: https://servicodados.ibge.gov.br/api/docs/agregados

## Identificação acadêmica

Projeto desenvolvido para a disciplina **ED 2026-02**.

Celine Souza RA 1141352623047
Lucas Rubira Oliveira RA 1141352623045
Emilly Caroline RA 1141352523042

